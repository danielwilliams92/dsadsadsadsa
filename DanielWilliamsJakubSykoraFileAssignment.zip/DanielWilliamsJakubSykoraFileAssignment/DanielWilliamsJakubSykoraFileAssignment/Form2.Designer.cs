﻿namespace DanielWilliamsJakubSykoraFileAssignment
{
    partial class employeeOutputForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtOutEmployeesHoursWorked = new System.Windows.Forms.TextBox();
            this.txtOutEmployeesNumber = new System.Windows.Forms.TextBox();
            this.txtOutEmployeesName = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnNext = new System.Windows.Forms.Button();
            this.txtOutWeeklyPay = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(79, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employees Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Employees name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Employees Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Hours Worked";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Weekly Pay";
            // 
            // txtOutEmployeesHoursWorked
            // 
            this.txtOutEmployeesHoursWorked.Location = new System.Drawing.Point(172, 173);
            this.txtOutEmployeesHoursWorked.Name = "txtOutEmployeesHoursWorked";
            this.txtOutEmployeesHoursWorked.ReadOnly = true;
            this.txtOutEmployeesHoursWorked.Size = new System.Drawing.Size(100, 20);
            this.txtOutEmployeesHoursWorked.TabIndex = 0;
            this.txtOutEmployeesHoursWorked.TabStop = false;
            // 
            // txtOutEmployeesNumber
            // 
            this.txtOutEmployeesNumber.Location = new System.Drawing.Point(172, 139);
            this.txtOutEmployeesNumber.Name = "txtOutEmployeesNumber";
            this.txtOutEmployeesNumber.ReadOnly = true;
            this.txtOutEmployeesNumber.Size = new System.Drawing.Size(149, 20);
            this.txtOutEmployeesNumber.TabIndex = 0;
            this.txtOutEmployeesNumber.TabStop = false;
            // 
            // txtOutEmployeesName
            // 
            this.txtOutEmployeesName.Location = new System.Drawing.Point(172, 103);
            this.txtOutEmployeesName.Name = "txtOutEmployeesName";
            this.txtOutEmployeesName.ReadOnly = true;
            this.txtOutEmployeesName.Size = new System.Drawing.Size(220, 20);
            this.txtOutEmployeesName.TabIndex = 0;
            this.txtOutEmployeesName.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(34, 269);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "&Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtOutWeeklyPay
            // 
            this.txtOutWeeklyPay.Location = new System.Drawing.Point(172, 210);
            this.txtOutWeeklyPay.Name = "txtOutWeeklyPay";
            this.txtOutWeeklyPay.ReadOnly = true;
            this.txtOutWeeklyPay.Size = new System.Drawing.Size(100, 20);
            this.txtOutWeeklyPay.TabIndex = 0;
            this.txtOutWeeklyPay.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(317, 269);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(278, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "@$10.50/hour";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(193, 321);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(224, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Daniel Williams - Jakub Sykora";
            // 
            // employeeOutputForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 346);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txtOutWeeklyPay);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtOutEmployeesHoursWorked);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.txtOutEmployeesNumber);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtOutEmployeesName);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(445, 384);
            this.MinimumSize = new System.Drawing.Size(445, 384);
            this.Name = "employeeOutputForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Output Form";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtOutEmployeesHoursWorked;
        private System.Windows.Forms.TextBox txtOutEmployeesNumber;
        private System.Windows.Forms.TextBox txtOutEmployeesName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.TextBox txtOutWeeklyPay;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}