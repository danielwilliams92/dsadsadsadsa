﻿using System;

public class Employee
{
    String firstName;
    int number, hoursWorked;

	public Employee(String fn, int number, int hoursWorked)
	{
        this.firstName = fn;
        this.number = number;
        this.hoursWorked = hoursWorked;
	}

    public double calculatePay(int hoursWorked)
    {
        return this.hoursWorked * 10.50;
    }
}
