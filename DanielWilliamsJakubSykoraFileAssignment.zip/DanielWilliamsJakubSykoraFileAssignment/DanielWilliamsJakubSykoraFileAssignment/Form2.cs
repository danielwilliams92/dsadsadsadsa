﻿/*
 *      Name:       Daniel Williams
 *                  Jakub
 *      
 *      Date:       December 5, 2016
 *      
 *      Purpose:    Allows a user to view all the employees that are within a text file. The user can click next to view the next
 *                  employee untill the list is complete, or until they exit.
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DanielWilliamsJakubSykoraFileAssignment
{
    public partial class employeeOutputForm : Form 
    {
        
        ArrayList list = new ArrayList();

        private StreamReader employeeStreamReader;

        public employeeOutputForm()
        {
            InitializeComponent();
        }

        // When form loads, asks user to selected the txt file to get employee information from
        private void Form2_Load(object sender, EventArgs e)
        {
            // User selects a file to open 
            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            openFileDialog1.FileName = "Employees.txt";
            openFileDialog1.Title = "select file";
            openFileDialog1.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";
            DialogResult response = openFileDialog1.ShowDialog();
            if (response == DialogResult.Cancel)
            {
                this.Close();
            }

            employeeStreamReader = new StreamReader(openFileDialog1.FileName);

           
            
            // Reads the file, adds value to a String, Splits the String, Displays
            try
            {
                String value = employeeStreamReader.ReadLine();
                txtOutEmployeesName.Text = value.Split(',')[0];
                txtOutEmployeesNumber.Text = value.Split(',')[1];
                txtOutEmployeesHoursWorked.Text = value.Split(',')[2];
                double totalPay = Int32.Parse(txtOutEmployeesHoursWorked.Text = value.Split(',')[2]) * 10.50;
                txtOutWeeklyPay.Text = totalPay.ToString("C");
            }
            // If no more files to be read, Next button is disabled
            catch (Exception)
            {
                btnNext.Enabled = false;
            } 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // if Stream reader isn't finish
                if (!employeeStreamReader.EndOfStream)
                {
                    String value = employeeStreamReader.ReadLine();
                    txtOutEmployeesName.Text = value.Split(',')[0];
                    txtOutEmployeesNumber.Text = value.Split(',')[1];
                    txtOutEmployeesHoursWorked.Text = value.Split(',')[2];
                    double totalPay = Int32.Parse(txtOutEmployeesHoursWorked.Text = value.Split(',')[2]) * 10.50;
                    txtOutWeeklyPay.Text = totalPay.ToString("C");
                }
                // if no more employees, disabled next button
                else
                {
                    btnNext.Enabled = false;
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Error");
            }

            } //end method

        // Exits the application
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
