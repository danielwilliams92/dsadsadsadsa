﻿/*
 *      Name:       Daniel Williams
 *                  Jakub
 *      
 *      Date:       December 5, 2016
 *      
 *      Purpose:    Allows a user to enter a employees name, number, and hours worked. The user can save the employee, which will then be saved
 *                  into a text file. The user can open up a second output form, which allows the user to hit next to review all the employees
 *                  that are in the saved text file.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DanielWilliamsJakubSykoraFileAssignment
{
    public partial class employeeInputForm : Form
    {
      
        private StreamWriter employeeStreamWriter;
        ArrayList list = new ArrayList();// Array to hold all employee objects that are created

    public employeeInputForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Opens a directory for the user to save a new file, or overwrite a file
            saveFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            saveFileDialog1.FileName = "Employees.txt";
            saveFileDialog1.DefaultExt = "txt";
            saveFileDialog1.Title = "Save the employee";
            saveFileDialog1.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";
            DialogResult response = saveFileDialog1.ShowDialog();

            // If user selects cancel, application closes
            if (response == DialogResult.Cancel)
            {
                this.Close();
            }    
        }//end form1_load

        private void btnSave_Click(object sender, EventArgs e)
        {
            Boolean proceed = true; //Boolean that if turns false, won't allow for a save
          
            // Makes sures employees name isn't empty
            if (string.IsNullOrWhiteSpace(txtEmployeesName.Text))
            {
                    proceed = false;
                    MessageBox.Show("Please enter a name","Invalid Input",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                    txtEmployeesName.Focus();
            }
            // If name isn't null or empty, it continues
            else
            {
                // Makes sure employees number isn't empty
                if (txtEmployeesNumber.Text.Trim() != null)
                {
                    // Checks to see if Employee Number can be converted to an Int
                    try
                    {
                        int empNumber = Int32.Parse(txtEmployeesNumber.Text);
                    }
                    // Catches a error if Employee Number can't be convereted to an Int
                    catch (Exception ex)
                    {
                        proceed = false;
                        MessageBox.Show("Please enter a number only", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtEmployeesNumber.Focus();
                    }
                    // Checks to see if employees hours worked is not empty
                    if (txtEmployeesHoursWorked.Text.Trim() != null)
                    {
                        // Checks to see if employees hours worked can be conveted to an Int
                        try
                        {
                            int empHours = Int32.Parse(txtEmployeesHoursWorked.Text);
                            // If hours worked are not between 0-40, message is shown and proceed set to false
                            if (Int32.Parse(txtEmployeesHoursWorked.Text) < 0 || Int32.Parse(txtEmployeesHoursWorked.Text) > 40)
                            {
                                proceed = false;
                                MessageBox.Show("Please enter from 0-40", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                txtEmployeesHoursWorked.Focus();
                            }
                        }
                        // Catches a error if employee hours worked, can't be converted to an Int
                        catch (Exception ex)
                        {
                            proceed = false;
                            MessageBox.Show("Please enter a number","Invalid Input",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                            txtEmployeesHoursWorked.Focus();
                        }

                        //Passed all field controls, Will now proceed to save employee information
                        if (proceed == true)
                        {
                            // Set up save file dialog
                            saveFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
                            saveFileDialog1.FileName = "Employees.txt";
                            saveFileDialog1.DefaultExt = "txt";
                            saveFileDialog1.Title = "Save the employee";
                            saveFileDialog1.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";

                            DialogResult response = saveFileDialog1.ShowDialog();

                            // If user selects somewhere to save, continue
                            if (response != DialogResult.Cancel)
                            {
                                // Puts all the textfields into an String array, with the values seperated by a comma',', into a ArrayList
                                try
                                {
                                    employeeStreamWriter = new StreamWriter(saveFileDialog1.FileName);
                                    String value = txtEmployeesName.Text + "," + txtEmployeesNumber.Text + "," + txtEmployeesHoursWorked.Text;
                                    list.Add(value);

                                    // Writes each String into the txt file within the array
                                    foreach (string i in list)
                                    {
                                        employeeStreamWriter.WriteLine(i);
                                    }
                                }

                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message, "File Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }

                                // Reached the end, if StreamWriter is opened, it will be closed, and TextBoxes will be cleared
                                finally
                                {
                                    if (employeeStreamWriter != null)
                                    {
                                        employeeStreamWriter.Close();

                                    }

                                    Clear();
                                }
                            }//4th if
                        }//3rd if  
                    }//2nd if
                }//1st if
            }//else
        } //End
          


        // When user clicks done, input form is hidden, output form is loaded, then input form is closed
        private void btnDone_Click(object sender, EventArgs e)
        {
            this.Hide();
            employeeOutputForm frm = new employeeOutputForm();
            frm.ShowDialog();
            this.Close();
        }

        // Clears all the TextBoxes
        private void Clear()
        {
            txtEmployeesName.Text = "";
            txtEmployeesNumber.Text = "";
            txtEmployeesHoursWorked.Text = "";
            txtEmployeesName.Focus();
        }

        // Exits the app
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        //last time I deleted one of these my program completely crashed
        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        //last time I deleted one of these my program completely crashed
        private void txtEmployeesName_TextChanged(object sender, EventArgs e)
        {

        }
       
    }
}
